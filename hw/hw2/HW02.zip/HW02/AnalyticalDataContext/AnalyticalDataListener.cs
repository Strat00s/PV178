﻿namespace HW02.AnalyticalDataContext
{
    public class AnalyticalDataListener
    {
        public AnalyticalDataListener()
        {
        }

        // TODO: implement the listener here
    }
}

﻿namespace HW02
{
    public class LoggerListener
    {
        public LoggerListener()
        {

        }

        // TODO: implement listener there
    }
}

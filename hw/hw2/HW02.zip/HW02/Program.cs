﻿namespace HW02
{
    public class Program
    {
        public static void Main()
        {
            // TODO: Initialize all clases here, when some dependency needed, insert object through constrcutor
            Console.WriteLine("Hello Ehop!");
        }
    }
}

# Opravy zadání ke dni 19.3.2023

## 19-03-2023
- Opraven test v 11. query, aby seděl s textovým zadáním
- Opraveno handlování oddělovače desetinných míst v testech při různých lokalizacích systému
- Opraven test ve 3. query, aby seděl s textovým zadáním
- Opraven test v 13. query, aby seděl s daty
- Navrácen požadavek na 5 záznamů do 11. query
- Opravena pomocná testovací metoda použitá v 7. query 

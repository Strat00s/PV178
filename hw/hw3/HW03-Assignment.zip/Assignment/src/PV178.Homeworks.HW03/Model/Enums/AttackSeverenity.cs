﻿namespace PV178.Homeworks.HW03.Model.Enums
{
    public enum AttackSeverenity
    {
        Fatal,
        NonFatal,
        Unknown
    }
}

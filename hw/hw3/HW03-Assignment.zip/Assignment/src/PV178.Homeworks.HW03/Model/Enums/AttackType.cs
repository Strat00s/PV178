﻿namespace PV178.Homeworks.HW03.Model.Enums
{
    public enum AttackType
    {
        Provoked, Unprovoked, SeaDisaster, Boating, Unknown
    }
}

﻿namespace PV178.Homeworks.HW03.Model.Enums
{
    public enum Sex
    {
        Male, Female, Unknown
    }
}

﻿Console.WriteLine("Welcome to HW03, you can use this file as a playground for manually testing your solution.");

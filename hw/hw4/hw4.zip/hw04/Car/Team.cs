namespace hw04.Car;

public class Team
{
    public string Name { get; }
    public Team(string name)
    {
        Name = name;
    }
}